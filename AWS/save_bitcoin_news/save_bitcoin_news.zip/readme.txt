for the terminal : 
go to the folder of the files and open in intgreated terminal 
zip -r save_bitcoin_news.zip .