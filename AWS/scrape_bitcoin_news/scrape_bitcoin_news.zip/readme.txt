open in intgreated terminal from the folder : 
install requests:
pip install requests -t .
install beautifulsoup:
pip install beautifulsoup4 -t .


then zip it : 
zip -r scrape_bitcoin_news.zip .

